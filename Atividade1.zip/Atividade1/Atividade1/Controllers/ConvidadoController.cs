﻿using Atividade1.Models;
using Microsoft.AspNetCore.Mvc;

namespace Atividade1.Controllers
{
    public class ConvidadoController : Controller
    {

        public static IList<Convidado> Convidados = new List<Convidado>()
        {
            new Convidado()
            {
                Id = 1,
                Nome = "Gabriel",
                Email = "gabriel.lapa@gmail.com",
                Telefone = "(35)988213435",
                comparecimento = true,
            },
            new Convidado()
            {
                Id = 2,
                Nome = "Vinico",
                Email = "vinico.cruz@gmail.com",
                Telefone = "(35)991007704",
                comparecimento = true,
            },
            new Convidado()
            {
                Id = 3,
                Nome = "Alice",
                Email = "alice.avila@gmail.com",
                Telefone = "(35)988745611",
                comparecimento = false,
            }
            ,
            new Convidado()
            {
                Id = 4,
                Nome = "Duda",
                Email = "duda.monteiro@gmail.com",
                Telefone = "(35)988209080",
                comparecimento = false,
            },

        };

        public IActionResult Index()
        {
            return View(Convidados.OrderBy(conv => conv.Id));
        }

        public IActionResult ViewConvidadosConfirmados()
        {
            return View(Convidados.Where(conv => conv.comparecimento == true));
        }

        public IActionResult Create()
        {
            return View(new Convidado());
        }
        [HttpPost]
        public IActionResult Create(Convidado convidado)
        {
            Convidados.Add(convidado);
            convidado.Id = Convidados.Select(conv => conv.Id).Max() + 1;
            return RedirectToAction("Index");
        }

        public IActionResult Details(int? id)
        {
            Convidado convidado = Convidados.FirstOrDefault(cat => cat.Id == id);

            return View(convidado);
        }

        public IActionResult Edit(int id)
        {
            Convidado convidado = Convidados.FirstOrDefault(cat => cat.Id == id);



            return View(convidado);
        }

        [HttpPost]

        public IActionResult Edit(Convidado convidado)
        {
            Convidados.Remove(Convidados.Where(cat => cat.Id == convidado.Id).First());
            Convidados.Add(convidado);
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            Convidado convidado = Convidados.FirstOrDefault(cat => cat.Id == id);
            if (convidado == null)
            {
                return NotFound();
            }

            Convidados.Remove(convidado);
            return RedirectToAction("Index");
        }
    }
}
